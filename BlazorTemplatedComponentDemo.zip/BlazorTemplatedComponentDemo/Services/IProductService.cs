﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorTemplatedComponentDemo.Models;

namespace BlazorTemplatedComponentDemo.Services
{
    public interface IProductService
    {
        List<Product> GetTopSellingProducts();
    }
}
